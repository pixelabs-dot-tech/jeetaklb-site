# El King Resto website

Static site. No build step, no dependencies. Upload the folder to any host (GitHub Pages, Netlify, Hostinger).

## Edit content
Everything editable lives in `assets/js/menu-data.js`:
- `ELKING`: phone, WhatsApp number, social links, maps link, jeetak link, opening hours, prefilled WhatsApp messages
- `ELKING_MENU`: categories and items (USD prices from the official menu; `price: null` shows "ask")
- `ELKING_MOODS`: the "Which one are you?" combos

## Before going live
- `facebook` in menu-data.js points to a Facebook search. Replace it with the real page URL.
- `hours` is `null` (hidden). Add opening hours to show them under the address.
- `jeetak` points to jeetaklb.com. Swap in El King's store link once it's live.
- In `index.html`, remove the `robots noindex` line (the preview build is hidden from Google) and point `og:url` and `og:image` at the real domain.

## How ordering works
Visitors add items, pick bread (Lebnene / Franje / Not sure), choose delivery, pickup or dine-in, then tap **Send order on WhatsApp**. That opens WhatsApp with the full order prefilled to 81 02 90 03. The cart is kept in the visitor's browser between visits.

## Structure
```
index.html
site.webmanifest
assets/css/site.css
assets/js/menu-data.js   ← content
assets/js/site.js        ← interactions
assets/img/              ← logo (vector), food cutouts, feed tiles, icons, og.jpg
assets/video/            ← three TikTok clips (H.264, faststart) + posters
assets/fonts/            ← self-hosted Anton, Barlow Condensed, Permanent Marker, Lalezar, Tajawal
```
