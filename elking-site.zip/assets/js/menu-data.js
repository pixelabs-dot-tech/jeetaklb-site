/* =====================================================================
   EL KING RESTO — site content
   Edit this file to change prices, items, links or contact details.
   - price: number in USD, or null to show "ask" (ask us, or see it on jeetak)
   - sizes: { S: 3, L: 5 } for items sold in two sizes
   ===================================================================== */

window.ELKING = {
  name: 'El King Resto',
  phoneDisplay: '81 02 90 03',
  phoneIntl: '+96181029003',
  instagram: 'https://www.instagram.com/elkinglb/',
  tiktok: 'https://www.tiktok.com/@elkinglb',
  facebook: 'https://www.facebook.com/search/top?q=El%20King%20Resto', // TODO: swap for the real page URL (page name: El KING RESTO)
  maps: 'https://www.google.com/maps/search/?api=1&query=El%20King%20Resto%20Khalwat%20Falougha%20Hammana',
  jeetak: 'https://jeetaklb.com',          // every order button points here: swap for El King's store link on jeetak once it is live
  hours: null,                             // e.g. 'Open daily, 12 pm – 12 am'. null hides the line.
};

window.ELKING_MENU = [
  {
    id: 'royalties', name: 'El King Royalties', bread: true,
    note: 'The old-school Lebanese offal sandwiches. Strictly for royalty.',
    items: [
      { id: 'n5a3at',       en: 'N5a3at',       ar: 'نخاعات',   price: 6 },
      { id: 'sanesel',      en: 'Sanesel',      ar: 'سناسل',    price: 8 },
      { id: 'fateyel',      en: 'Fateyel',      ar: 'فتايل',    price: 7 },
      { id: 'lsenet',       en: 'Lsenet',       ar: 'لسانات',   price: 5 },
      { id: 'beid-ghanam',  en: 'Beid Ghanam',  ar: 'بيض غنم',  price: 6 },
      { id: 'sawda-ghanam', en: 'Sawda Ghanam', ar: 'سودة غنم', price: 6 },
    ],
  },
  {
    id: 'specialities', name: 'El King Specialities', bread: true,
    note: 'Lebanese street classics on the bread of your choice.',
    items: [
      { id: 'rosto',       en: 'Rosto',       ar: 'روستو',     price: 5 },
      { id: 'sojouk',      en: 'Sojouk',      ar: 'سجق',       price: 5.5 },
      { id: 'makanek',     en: 'Makanek',     ar: 'مقانق',     price: 5.5 },
      { id: 'basterma',    en: 'Basterma',    ar: 'بسطرمة',    price: 5.5 },
      { id: 'kafta',       en: 'Kafta',       ar: 'كفتة',      price: 5 },
      { id: 'djeij',       en: 'Djeij',       ar: 'دجاج',      price: 4.5 },
      { id: 'sawda-djeij', en: 'Sawda Djeij', ar: 'سودة دجاج', price: 4.5 },
      { id: 'tawouk',      en: 'Tawouk',      ar: 'طاووق',     price: 5 },
    ],
  },
  {
    id: 'burgers', name: 'El King Burgers',
    note: 'Stacked, saucy and impossible to eat politely.',
    peek: { src: 'assets/img/burger-lebanese.webp', w: 624, h: 515 },
    items: [
      { id: 'flat-beef',        en: 'Flat Beef Burger',     ar: 'برجر لحمة',        price: 6 },
      { id: 'flat-chicken',     en: 'Flat Chicken Burger',  ar: 'برجر دجاج',        price: 5 },
      { id: 'chicken-mushroom', en: 'Chicken Mushroom',     ar: 'دجاج بالفطر',      price: 7 },
      { id: 'lebanese-burger',  en: 'Lebanese Burger',      ar: 'برجر لبنانية',     price: 5 },
      { id: 'kings-burger',     en: "King's Burger",        ar: 'كينغز برجر',       price: null, star: true },
      { id: 'kings-supreme',    en: "King's Supreme",       ar: 'كينغز سوبريم',     price: null },
      { id: 'crispy-burger',    en: 'Crispy Burger',        ar: 'كريسبي برجر',      price: null },
      { id: 'beef-mushroom',    en: 'Beef Mushroom',        ar: 'برجر لحمة بالفطر', price: null },
      { id: 'american-beef',    en: 'American Beef Burger', ar: 'برجر أميركي',      price: null },
    ],
  },
  {
    id: 'plates', name: 'Plates & Salads',
    note: 'For when one sandwich simply will not do.',
    peek: { src: 'assets/img/caesar-bowl.webp', w: 900, h: 900 },
    items: [
      { id: 'crispy-meal',   en: 'Crispy Meal',          ar: 'وجبة كريسبي',       price: null },
      { id: 'chicken-plate', en: 'Chicken Plate',        ar: 'صحن دجاج',          price: null },
      { id: 'tawouk-plate',  en: 'Tawouk Plate',         ar: 'صحن طاووق',         price: null },
      { id: 'steak-plate',   en: 'Shredded Steak Plate', ar: 'صحن ستيك',          price: null },
      { id: 'loaded-fries',  en: 'Loaded Fries',         ar: 'بطاطا لودد',        price: null },
      { id: 'caesar',        en: 'Chicken Caesar Salad', ar: 'سلطة سيزر بالدجاج', price: null },
      { id: 'greek',         en: 'Greek Salad',          ar: 'سلطة يونانية',      price: null },
      { id: 'crab-salad',    en: 'Crab Salad',           ar: 'سلطة كراب',         price: null },
    ],
  },
  {
    id: 'seafood', name: 'El King Seafood', bread: true,
    note: 'From raw to wow.',
    items: [
      { id: 'octopus',         en: 'Octopus',           ar: 'أخطبوط',      price: 9 },
      { id: 'calamari',        en: 'Calamari',          ar: 'كالامار',     price: 7 },
      { id: 'shrimp',          en: 'Shrimp',            ar: 'قريدس',       price: 7 },
      { id: 'tuna',            en: 'Tuna',              ar: 'تونا',        price: 5 },
      { id: 'crab',            en: 'Crab',              ar: 'كراب',        price: 5 },
      { id: 'mix-crab-shrimp', en: 'Mix Crab & Shrimp', ar: 'كراب وقريدس', price: null },
    ],
  },
  {
    id: 'appetizers', name: 'Appetizers',
    note: 'مين بياخد الأخيرة؟ Who takes the last one?',
    items: [
      { id: 'fries',            en: 'Fries',              ar: 'بطاطا',          sizes: { S: 3, L: 5 } },
      { id: 'wedges',           en: 'Wedges',             ar: 'ودجز',           sizes: { S: 3, L: 5 } },
      { id: 'osmaliyeh',        en: 'Chicken Osmaliyeh',  ar: 'دجاج بالعثملية', price: 5 },
      { id: 'halloum',          en: 'Crunchy Halloum',    ar: 'حلوم مقرمش',     price: 5 },
      { id: 'curly-fries',      en: 'Curly Fries',        ar: 'بطاطا كيرلي',    price: null },
      { id: 'breaded-calamari', en: 'Breaded Calamari',   ar: 'كالامار مقرمش',  price: null },
      { id: 'breaded-shrimp',   en: 'Breaded Shrimp',     ar: 'قريدس مقرمش',    price: null },
      { id: 'crab-claws',       en: 'Breaded Crab Claws', ar: 'كراب كلوز',      price: null },
      { id: 'jalapeno-bites',   en: 'Jalapeño Bites',     ar: 'هالابينو بايتس', price: null },
      { id: 'extra-dip',        en: 'Extra Dip',          ar: 'صوص إضافي',      price: null },
    ],
  },
  {
    id: 'drinks', name: 'El King Beverages',
    note: 'Diet? Pepsi diet.',
    items: [
      { id: 'soft-can',   en: 'Soft Drink (Can)',   ar: 'مشروب غازي تنك',  price: 1 },
      { id: 'soft-glass', en: 'Soft Drink (Glass)', ar: 'مشروب غازي قزاز', price: 0.5 },
      { id: 'water',      en: 'Water (Small)',      ar: 'مياه زغير',       price: 0.5 },
      { id: 'sparkling',  en: 'Sparkling Water',    ar: 'مياه غازية',      price: 1 },
      { id: 'juice',      en: 'Juice',              ar: 'عصير',            price: 0.5 },
    ],
  },
];

/* "Which one are you?" — each mood suggests a combo: [itemId, size?] */
window.ELKING_MOODS = [
  { id: 'enjoy',    label: 'Enjoy',    line: 'Sometimes a Tawouk sandwich is all I need to smile.',
    combo: [['tawouk'], ['soft-glass']] },
  { id: 'craving',  label: 'Craving',  line: 'I wasn’t hungry… until I saw the Flat Beef Burger.',
    combo: [['flat-beef'], ['fries', 'L']] },
  { id: 'addicted', label: 'Addicted', line: 'I dream about my next Chicken Mushroom before I finish the first.',
    combo: [['chicken-mushroom'], ['halloum'], ['soft-can']] },
  { id: 'obsessed', label: 'Obsessed', line: 'If I could marry a menu, it would be this one. The whole royal court, please.',
    combo: [['sanesel'], ['makanek'], ['calamari'], ['wedges', 'L']] },
];
