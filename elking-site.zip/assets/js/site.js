/* El King Resto — interactions. No dependencies. */
(function () {
  'use strict';

  var C = window.ELKING || {};
  var MENU = window.ELKING_MENU || [];
  var MOODS = window.ELKING_MOODS || [];
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  var STORE = 'elking-order-v1';

  /* ---------- helpers ---------- */
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function money(n) {
    var v = Math.round(n * 100) / 100;
    return '$' + (Number.isInteger(v) ? v : v.toFixed(2).replace(/0$/, ''));
  }
  function waLink(text) {
    return 'https://wa.me/' + (C.wa || '') + (text ? '?text=' + encodeURIComponent(text) : '');
  }
  function icon(id, cls) {
    return '<svg' + (cls ? ' class="' + cls + '"' : '') + ' aria-hidden="true"><use href="#' + id + '"/></svg>';
  }

  /* ---------- item index ---------- */
  var ITEMS = {};
  MENU.forEach(function (cat) {
    cat.items.forEach(function (it) {
      ITEMS[it.id] = Object.assign({}, it, { cat: cat.id, bread: !!cat.bread && it.bread !== false });
    });
  });
  function unitPrice(id, size) {
    var it = ITEMS[id];
    if (!it) return null;
    if (it.sizes) return size && it.sizes[size] != null ? it.sizes[size] : null;
    return typeof it.price === 'number' ? it.price : null;
  }
  function itemLabel(id, size) {
    var it = ITEMS[id];
    if (!it) return '';
    return it.en + (size ? (size === 'S' ? ' (small)' : size === 'L' ? ' (large)' : ' (' + size + ')') : '');
  }

  /* ---------- links from config ---------- */
  function applyLinks() {
    $$('[data-wa]').forEach(function (a) {
      var key = a.getAttribute('data-wa');
      a.href = waLink((C.messages && C.messages[key]) || (C.messages && C.messages.hello) || '');
    });
    $$('[data-link]').forEach(function (a) {
      var url = C[a.getAttribute('data-link')];
      if (url) a.href = url;
    });
    $$('[data-tel]').forEach(function (a) { if (C.phoneIntl) a.href = 'tel:' + C.phoneIntl; });
    var hours = $('[data-hours]');
    if (hours && C.hours) { hours.textContent = C.hours; hours.hidden = false; }
    $$('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });
  }

  /* =====================================================================
     MENU BOARDS
     ===================================================================== */
  function renderMenu() {
    var boards = $('[data-boards]');
    var cats = $('[data-cats]');
    if (!boards || !cats) return;

    cats.innerHTML = MENU.map(function (cat) {
      return '<a class="cat" href="#cat-' + cat.id + '" data-cat-link="' + cat.id + '">' + esc(shortName(cat.name)) + '</a>';
    }).join('');

    boards.innerHTML = MENU.map(function (cat) {
      var peek = cat.peek ? '<img class="board__peek" src="' + esc(cat.peek.src) + '" alt="" width="' + cat.peek.w + '" height="' + cat.peek.h + '" loading="lazy">' : '';
      return '<article class="board' + (cat.peek ? ' board--peek' : '') + '" id="cat-' + cat.id + '" data-cat="' + cat.id + '" aria-labelledby="t-' + cat.id + '">' +
        peek +
        '<h3 class="board__title" id="t-' + cat.id + '">' + esc(cat.name) + '</h3>' +
        (cat.note ? '<p class="board__note">' + esc(cat.note) + '</p>' : '') +
        '<ul class="list">' + cat.items.map(renderItem).join('') + '</ul>' +
        '</article>';
    }).join('');

    boards.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-add]');
      if (!btn) return;
      addToCart(btn.getAttribute('data-add'), btn.getAttribute('data-size') || null, 1);
      flashAdded(btn);
    });

    // Masonry: drop each board into the shortest column, keeping menu order.
    var boardEls = $$('.board', boards);
    var cols = 0;
    function layout() {
      var w = boards.clientWidth;
      var n = w >= 1040 ? 3 : w >= 660 ? 2 : 1;
      if (n === cols) return;
      cols = n;
      boards.style.setProperty('--cols', n);
      var columns = [];
      boards.innerHTML = '';
      for (var i = 0; i < n; i++) {
        var c = document.createElement('div');
        c.className = 'boards__col';
        boards.appendChild(c);
        columns.push(c);
      }
      boardEls.forEach(function (b) {
        var target = columns.reduce(function (a, c) { return c.offsetHeight < a.offsetHeight ? c : a; });
        target.appendChild(b);
      });
    }
    layout();
    var rt;
    window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(layout, 120); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { cols = 0; layout(); });
  }
  function shortName(name) { return name.replace(/^El King /, ''); }

  function renderItem(it) {
    var names = '<div class="item__names"><span class="item__en">' + esc(it.en) +
      (it.star ? icon('i-crown', 'item__star') : '') + '</span>' +
      '<span class="item__ar" lang="ar" dir="rtl">' + esc(it.ar || '') + '</span></div>';
    var buy;
    if (it.sizes) {
      buy = '<div class="sizes">' + Object.keys(it.sizes).map(function (s) {
        return '<button class="add add--size" type="button" data-add="' + it.id + '" data-size="' + s + '" aria-label="Add ' + esc(it.en) + ' ' + s + ' ' + money(it.sizes[s]) + ' (' + (s === 'S' ? 'small' : s === 'L' ? 'large' : s) + ')">' +
          s + ' <b>' + money(it.sizes[s]) + '</b>' + icon('i-plus') + '</button>';
      }).join('') + '</div>';
    } else {
      var p = typeof it.price === 'number' ? '<span class="price">' + money(it.price) + '</span>' : '<span class="price price--ask" title="Priced on WhatsApp">ask</span>';
      buy = '<div class="item__buy">' + p +
        '<button class="add" type="button" data-add="' + it.id + '" aria-label="Add ' + esc(it.en) + ' to your order">' + icon('i-plus') + '</button></div>';
    }
    return '<li class="item">' + names + '<span class="item__dots" aria-hidden="true"></span>' + buy + '</li>';
  }

  function flashAdded(btn) {
    btn.classList.add('is-added');
    var use = btn.querySelector('use');
    if (use) use.setAttribute('href', '#i-check');
    setTimeout(function () {
      btn.classList.remove('is-added');
      if (use) use.setAttribute('href', '#i-plus');
    }, 900);
  }

  /* category chips follow the scroll */
  function initCatSpy() {
    var links = $$('[data-cat-link]');
    if (!links.length || !('IntersectionObserver' in window)) return;
    var current = null;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          var id = en.target.getAttribute('data-cat');
          if (id === current) return;
          current = id;
          links.forEach(function (l) {
            var on = l.getAttribute('data-cat-link') === id;
            l.classList.toggle('is-on', on);
            if (on) {
              l.setAttribute('aria-current', 'true');
              var bar = l.parentElement;
              var target = l.offsetLeft - bar.clientWidth / 2 + l.clientWidth / 2;
              bar.scrollTo({ left: target, behavior: reduceMotion.matches ? 'auto' : 'smooth' });
            } else l.removeAttribute('aria-current');
          });
        }
      });
    }, { rootMargin: '-35% 0px -60% 0px' });
    $$('.board').forEach(function (b) { io.observe(b); });
  }

  /* =====================================================================
     CART
     ===================================================================== */
  var cart = { lines: [], type: 'Delivery', name: '', address: '', notes: '' };

  function load() {
    try {
      var s = JSON.parse(localStorage.getItem(STORE) || 'null');
      if (s && Array.isArray(s.lines)) {
        cart = Object.assign(cart, s);
        cart.lines = cart.lines.filter(function (l) { return ITEMS[l.id] && l.qty > 0; });
      }
    } catch (e) { /* storage unavailable: start fresh */ }
  }
  function save() {
    try { localStorage.setItem(STORE, JSON.stringify(cart)); } catch (e) { /* ignore */ }
  }
  function keyOf(id, size, bread) { return [id, size || '', bread || ''].join('|'); }

  function addToCart(id, size, qty) {
    var it = ITEMS[id];
    if (!it) return;
    if (it.sizes && !size) size = Object.keys(it.sizes)[0];
    var bread = it.bread ? 'ask' : null;
    var key = keyOf(id, size, bread);
    var line = cart.lines.filter(function (l) { return l.key === key; })[0];
    if (line) line.qty += qty;
    else cart.lines.push({ key: key, id: id, size: size || null, bread: bread, qty: qty });
    save();
    renderCart(true);
    toast('Added ' + itemLabel(id, size));
  }
  function setQty(key, qty) {
    cart.lines = cart.lines.map(function (l) { if (l.key === key) l.qty = qty; return l; }).filter(function (l) { return l.qty > 0; });
    save(); renderCart();
  }
  function setBread(key, bread) {
    var line = cart.lines.filter(function (l) { return l.key === key; })[0];
    if (!line) return;
    var nk = keyOf(line.id, line.size, bread);
    var twin = cart.lines.filter(function (l) { return l.key === nk; })[0];
    if (twin && twin !== line) { twin.qty += line.qty; line.qty = 0; }
    else { line.bread = bread; line.key = nk; }
    cart.lines = cart.lines.filter(function (l) { return l.qty > 0; });
    save(); renderCart();
  }
  function totals() {
    var sub = 0, count = 0, ask = 0;
    cart.lines.forEach(function (l) {
      var u = unitPrice(l.id, l.size);
      count += l.qty;
      if (u == null) ask += l.qty; else sub += u * l.qty;
    });
    return { sub: sub, count: count, ask: ask };
  }

  function buildMessage() {
    var t = totals();
    var out = ['Hi El King! 👑 New order from the website:', ''];
    cart.lines.forEach(function (l) {
      var it = ITEMS[l.id];
      var name = itemLabel(l.id, l.size);
      if (it.bread) name += l.bread && l.bread !== 'ask' ? ', ' + l.bread + ' bread' : ', bread: your recommendation';
      var u = unitPrice(l.id, l.size);
      out.push('• ' + l.qty + '× ' + name + ' — ' + (u == null ? 'price to confirm' : money(u * l.qty)));
    });
    out.push('');
    out.push('Subtotal: ' + money(t.sub) + (t.ask ? ' + ' + t.ask + ' item' + (t.ask > 1 ? 's' : '') + ' to price' : ''));
    out.push('Order type: ' + cart.type);
    if (cart.name.trim()) out.push('Name: ' + cart.name.trim());
    if (cart.type === 'Delivery') out.push('Address: ' + (cart.address.trim() || 'I will share my location'));
    if (cart.notes.trim()) out.push('Notes: ' + cart.notes.trim());
    return out.join('\n');
  }

  function renderCart(bump) {
    var t = totals();
    $$('[data-count]').forEach(function (el) {
      el.textContent = t.count;
      if (t.count) el.removeAttribute('data-zero'); else el.setAttribute('data-zero', '');
    });
    $$('[data-total]').forEach(function (el) { el.textContent = money(t.sub) + (t.ask ? '+' : ''); });
    var cartbtn = $('.cartbtn');
    if (cartbtn) cartbtn.setAttribute('aria-label', 'Your order, ' + t.count + ' item' + (t.count === 1 ? '' : 's'));
    var bar = $('[data-orderbar]');
    if (bar) {
      bar.classList.toggle('is-visible', t.count > 0);
      bar.setAttribute('aria-hidden', t.count > 0 ? 'false' : 'true');
      bar.tabIndex = t.count > 0 ? 0 : -1;
      bar.setAttribute('aria-label', 'Open your order: ' + t.count + ' item' + (t.count === 1 ? '' : 's') + ', ' + money(t.sub));
    }
    if (bump) {
      [cartbtn, bar].forEach(function (el) {
        if (!el) return;
        el.classList.remove('is-bump'); void el.offsetWidth; el.classList.add('is-bump');
      });
    }

    var drawer = $('[data-drawer]');
    if (!drawer) return;
    drawer.classList.toggle('is-empty', t.count === 0);
    var list = $('[data-lines]');
    list.innerHTML = cart.lines.map(function (l) {
      var it = ITEMS[l.id];
      var u = unitPrice(l.id, l.size);
      var price = u == null ? '<span class="line__price line__price--ask">price on<br>WhatsApp</span>' : '<span class="line__price">' + money(u * l.qty) + '</span>';
      var bread = '';
      if (it.bread) {
        var b = C.breads || { Lebnene: 'Lebnene', Franje: 'Franje', ask: 'Not sure' };
        bread = '<div class="seg" role="group" aria-label="Bread for ' + esc(it.en) + '">' + Object.keys(b).map(function (k) {
          return '<button type="button" data-bread="' + k + '" data-key="' + esc(l.key) + '" aria-pressed="' + (l.bread === k) + '">' + esc(b[k]) + '</button>';
        }).join('') + '</div>';
      }
      return '<li class="line">' +
        '<div class="line__top"><span>' + esc(itemLabel(l.id, l.size)) + '</span>' + price + '</div>' +
        '<div class="line__ar" lang="ar" dir="rtl">' + esc(it.ar || '') + '</div>' +
        '<div class="line__row">' + (bread || '<span></span>') +
        '<div class="qty"><button type="button" data-dec="' + esc(l.key) + '" aria-label="One less ' + esc(it.en) + '">' + icon('i-minus') + '</button>' +
        '<span aria-live="polite">' + l.qty + '</span>' +
        '<button type="button" data-inc="' + esc(l.key) + '" aria-label="One more ' + esc(it.en) + '">' + icon('i-plus') + '</button></div>' +
        '</div></li>';
    }).join('');

    $('[data-subtotal]').textContent = money(t.sub);
    $('[data-asknote]').textContent = (t.ask ? t.ask + ' item' + (t.ask > 1 ? 's' : '') + ' priced on WhatsApp. ' : '') + 'We confirm the final total before you pay.';
    var addr = $('[data-address-field]');
    if (addr) addr.hidden = cart.type !== 'Delivery';
    var send = $('[data-send]');
    if (send) send.href = waLink(buildMessage());
  }

  function initCart() {
    load();
    var drawer = $('[data-drawer]');
    if (!drawer) return;
    var form = $('[data-form]');
    // restore form fields
    $$('input[name="type"]', form).forEach(function (r) { r.checked = r.value === cart.type; });
    ['name', 'address', 'notes'].forEach(function (n) {
      var f = form.querySelector('[name="' + n + '"]');
      if (f) f.value = cart[n] || '';
    });
    form.addEventListener('input', function (e) {
      var n = e.target.name;
      if (n === 'type') cart.type = e.target.value;
      else if (n in cart) cart[n] = e.target.value;
      save();
      if (n === 'type') renderCart();
      else { var send = $('[data-send]'); if (send) send.href = waLink(buildMessage()); }
    });
    form.addEventListener('change', function (e) {
      if (e.target.name === 'type') { cart.type = e.target.value; save(); renderCart(); }
    });

    drawer.addEventListener('click', function (e) {
      var t = e.target.closest('button, a');
      if (!t) return;
      var k;
      if ((k = t.getAttribute('data-inc'))) { var l = lineBy(k); if (l) setQty(k, l.qty + 1); }
      else if ((k = t.getAttribute('data-dec'))) { var l2 = lineBy(k); if (l2) setQty(k, l2.qty - 1); }
      else if (t.hasAttribute('data-bread')) setBread(t.getAttribute('data-key'), t.getAttribute('data-bread'));
      else if (t.hasAttribute('data-clear')) { cart.lines = []; save(); renderCart(); toast('Order cleared'); }
      else if (t.hasAttribute('data-send')) { t.href = waLink(buildMessage()); }
    });

    $$('[data-open-cart]').forEach(function (b) { b.addEventListener('click', openCart); });
    $$('[data-close-cart]').forEach(function (b) { b.addEventListener('click', closeCart); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !drawer.hidden) closeCart();
      if (e.key === 'Tab' && !drawer.hidden) trapFocus(e, $('.drawer__panel', drawer));
    });
    renderCart();
  }
  function lineBy(key) { return cart.lines.filter(function (l) { return l.key === key; })[0]; }

  var lastFocus = null;
  function openCart() {
    var drawer = $('[data-drawer]');
    lastFocus = document.activeElement;
    closeMobileNav();
    var tEl = $('[data-toast]');
    if (tEl) { clearTimeout(toastTimer); tEl.classList.remove('is-on'); }
    drawer.hidden = false;
    document.documentElement.style.overflow = 'hidden';
    requestAnimationFrame(function () {
      drawer.classList.add('is-open');
      var close = $('.drawer__head .iconbtn', drawer);
      if (close) close.focus({ preventScroll: true });
    });
  }
  function closeCart() {
    var drawer = $('[data-drawer]');
    if (drawer.hidden) return;
    drawer.classList.remove('is-open');
    document.documentElement.style.overflow = '';
    setTimeout(function () { drawer.hidden = true; }, reduceMotion.matches ? 0 : 380);
    if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
  }
  function trapFocus(e, root) {
    var f = $$('a[href], button:not([disabled]), input, textarea, select, [tabindex]:not([tabindex="-1"])', root)
      .filter(function (el) { return el.offsetParent !== null; });
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }

  var toastTimer;
  function toast(msg) {
    var el = $('[data-toast]');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('is-on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('is-on'); }, 1800);
  }

  /* =====================================================================
     CRAVING CALLING — slide to answer
     ===================================================================== */
  function initCall() {
    var root = $('[data-call]');
    if (!root) return;
    var track = $('.call__track', root), knob = $('[data-call-knob]', root);
    var label = $('[data-call-label]', root), status = $('[data-call-status]', root);
    var x = 0, max = 0, startX = 0, dragging = false, moved = false, answered = false, timer = null, resetT = null;

    function measure() { max = Math.max(0, track.clientWidth - knob.offsetWidth - 10); }
    function setX(v, animate) {
      x = Math.max(0, Math.min(max, v));
      knob.style.transition = animate ? 'transform .5s cubic-bezier(.34,1.56,.64,1)' : 'none';
      knob.style.transform = 'translateX(' + x + 'px)';
      root.style.setProperty('--p', max ? (x / max).toFixed(3) : 0);
    }
    knob.addEventListener('pointerdown', function (e) {
      if (answered) return;
      measure(); dragging = true; moved = false; startX = e.clientX - x;
      try { knob.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      root.classList.add('is-dragging');
    });
    knob.addEventListener('pointermove', function (e) {
      if (!dragging) return;
      var nx = e.clientX - startX;
      if (Math.abs(nx - x) > 2) moved = true;
      setX(nx, false);
    });
    function end() {
      if (!dragging) return;
      dragging = false;
      root.classList.remove('is-dragging');
      if (x >= max * 0.85) answer();
      else setX(0, true);
    }
    knob.addEventListener('pointerup', end);
    knob.addEventListener('pointercancel', end);
    knob.addEventListener('click', function (e) {
      if (answered) return;
      if (e.detail === 0) { measure(); answer(); return; } // keyboard
      if (!moved) { // a tap: show how it works
        root.classList.remove('is-nudge'); void root.offsetWidth; root.classList.add('is-nudge');
        status.textContent = 'Slide the food to the right to answer.';
      }
    });
    window.addEventListener('resize', function () { if (answered) { measure(); setX(max, false); } });

    function answer() {
      answered = true;
      setX(max, true);
      root.classList.add('is-answered');
      var s = 0;
      label.textContent = 'Connected 0:00';
      clearInterval(timer);
      timer = setInterval(function () { s++; label.textContent = 'Connected 0:' + (s < 10 ? '0' : '') + s; }, 1000);
      status.textContent = 'Opening WhatsApp… tell us what you’re craving.';
      window.open(waLink((C.messages && C.messages.call) || ''), '_blank', 'noopener');
      clearTimeout(resetT);
      resetT = setTimeout(reset, 12000);
    }
    function reset() {
      answered = false;
      clearInterval(timer);
      root.classList.remove('is-answered');
      label.textContent = 'slide to answer';
      status.textContent = '';
      measure(); setX(0, true);
    }
  }

  /* =====================================================================
     WHICH ONE ARE YOU? gauge
     ===================================================================== */
  function initGauge() {
    var g = $('[data-gauge]');
    if (!g || !MOODS.length) return;
    var segs = $$('.gauge__seg', g), needle = $('.gauge__needle', g);
    var quote = $('[data-gauge-quote]', g), combo = $('[data-gauge-combo]', g), total = $('[data-gauge-total]', g), addBtn = $('[data-gauge-add]', g);
    var current = 1;
    function select(i) {
      current = i;
      var m = MOODS[i];
      segs.forEach(function (s, j) { s.classList.toggle('is-on', j === i); s.setAttribute('aria-pressed', j === i ? 'true' : 'false'); });
      needle.style.transform = 'rotate(' + (-67.5 + i * 45) + 'deg)';
      quote.textContent = '“' + m.line + '”';
      var sum = 0, ask = 0;
      combo.innerHTML = m.combo.map(function (c) {
        var u = unitPrice(c[0], c[1]);
        if (u == null) ask++; else sum += u;
        return '<li>' + esc(itemLabel(c[0], c[1])) + '</li>';
      }).join('');
      total.textContent = money(sum) + (ask ? ' +' : '');
    }
    segs.forEach(function (s, i) {
      s.addEventListener('click', function () { select(i); });
      s.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(i); }
        if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
          e.preventDefault();
          var n = (i + (e.key === 'ArrowRight' ? 1 : -1) + segs.length) % segs.length;
          segs[n].focus(); select(n);
        }
      });
    });
    addBtn.addEventListener('click', function () {
      MOODS[current].combo.forEach(function (c) { addToCart(c[0], c[1] || null, 1); });
      toast(MOODS[current].label + ' combo added');
    });
    select(current);
  }

  /* =====================================================================
     MOBILE NAV
     ===================================================================== */
  function initMobileNav() {
    var btn = $('[data-burger]'), panel = $('[data-mnav]');
    if (!btn || !panel) return;
    btn.addEventListener('click', function () {
      var open = btn.getAttribute('aria-expanded') !== 'true';
      btn.setAttribute('aria-expanded', open);
      panel.classList.toggle('is-open', open);
      document.documentElement.style.overflow = open ? 'hidden' : '';
    });
    panel.addEventListener('click', function (e) { if (e.target.closest('a')) closeMobileNav(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMobileNav(); });
  }
  function closeMobileNav() {
    var btn = $('[data-burger]'), panel = $('[data-mnav]');
    if (!btn || btn.getAttribute('aria-expanded') !== 'true') return;
    btn.setAttribute('aria-expanded', 'false');
    panel.classList.remove('is-open');
    document.documentElement.style.overflow = '';
  }

  /* =====================================================================
     VIDEOS — play when on screen, tap for sound
     ===================================================================== */
  function initReels() {
    var vids = $$('.reel video');
    if (!vids.length) return;
    var auto = !reduceMotion.matches;
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          var v = en.target;
          if (en.isIntersecting) {
            if (v.preload === 'none') v.preload = 'auto';
            if (auto) { var p = v.play(); if (p && p.catch) p.catch(function () {}); }
          } else v.pause();
        });
      }, { threshold: 0.4 });
      vids.forEach(function (v) { io.observe(v); });
    }
    $$('.reel__sound').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var v = btn.parentElement.querySelector('video');
        var turnOn = v.muted;
        vids.forEach(function (o) {
          o.muted = true;
          var b = o.parentElement.querySelector('.reel__sound');
          b.setAttribute('aria-pressed', 'false'); b.setAttribute('aria-label', 'Turn sound on');
        });
        v.muted = !turnOn;
        btn.setAttribute('aria-pressed', turnOn ? 'true' : 'false');
        btn.setAttribute('aria-label', turnOn ? 'Turn sound off' : 'Turn sound on');
        if (v.paused) { var p = v.play(); if (p && p.catch) p.catch(function () {}); }
      });
    });
    $$('.reel__frame video').forEach(function (v) {
      v.addEventListener('click', function () {
        if (v.paused) { var p = v.play(); if (p && p.catch) p.catch(function () {}); } else v.pause();
      });
    });
  }

  /* =====================================================================
     THE CREATION OF APPETITE — hands meet as you scroll
     ===================================================================== */
  function initCreation() {
    var art = $('[data-creation]');
    if (!art) return;
    if (reduceMotion.matches) { art.style.setProperty('--gap', '0%'); art.style.setProperty('--spark', 1); return; }
    var ticking = false, active = false;
    function update() {
      ticking = false;
      var r = art.getBoundingClientRect(), vh = window.innerHeight;
      var p = (vh - r.top) / (vh * 0.75 + r.height * 0.25);
      var q = Math.max(0, Math.min(1, p / 0.88));
      var eased = 1 - Math.pow(1 - q, 2);
      art.style.setProperty('--gap', ((1 - eased) * 16).toFixed(2) + '%');
      art.style.setProperty('--spark', q >= 1 ? 1 : 0);
    }
    function onScroll() { if (active && !ticking) { ticking = true; requestAnimationFrame(update); } }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) { active = en[0].isIntersecting; if (active) update(); }, { rootMargin: '20% 0px' }).observe(art);
    } else active = true;
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    update();
  }

  /* ---------- go ---------- */
  applyLinks();
  renderMenu();
  initCart();
  initCatSpy();
  initCall();
  initGauge();
  initMobileNav();
  initReels();
  initCreation();
})();
