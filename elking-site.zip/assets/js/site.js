/* El King Resto — interactions. No dependencies. */
(function () {
  'use strict';

  var C = window.ELKING || {};
  var MENU = window.ELKING_MENU || [];
  var MOODS = window.ELKING_MOODS || [];
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  var JK_MARK = '<svg class="jkmark" aria-hidden="true" focusable="false"><use href="#i-jk"/></svg>';

  /* ---------- helpers ---------- */
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function money(n) {
    var v = Math.round(n * 100) / 100;
    return '$' + (Number.isInteger(v) ? v : v.toFixed(2).replace(/0$/, ''));
  }
  function icon(id, cls) {
    return '<svg' + (cls ? ' class="' + cls + '"' : '') + ' aria-hidden="true"><use href="#' + id + '"/></svg>';
  }
  function openJeetak() {
    window.open(C.jeetak || 'https://jeetaklb.com', '_blank', 'noopener');
  }

  /* ---------- item index ---------- */
  var ITEMS = {};
  MENU.forEach(function (cat) {
    cat.items.forEach(function (it) { ITEMS[it.id] = it; });
  });
  function unitPrice(id, size) {
    var it = ITEMS[id];
    if (!it) return null;
    if (it.sizes) return size && it.sizes[size] != null ? it.sizes[size] : null;
    return typeof it.price === 'number' ? it.price : null;
  }
  function itemLabel(id, size) {
    var it = ITEMS[id];
    if (!it) return '';
    return it.en + (size ? (size === 'S' ? ' (small)' : size === 'L' ? ' (large)' : ' (' + size + ')') : '');
  }

  /* ---------- links from config ---------- */
  function applyLinks() {
    $$('[data-link]').forEach(function (a) {
      var url = C[a.getAttribute('data-link')];
      if (url) a.href = url;
    });
    $$('[data-tel]').forEach(function (a) { if (C.phoneIntl) a.href = 'tel:' + C.phoneIntl; });
    var hours = $('[data-hours]');
    if (hours && C.hours) { hours.textContent = C.hours; hours.hidden = false; }
    $$('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });
  }

  /* =====================================================================
     MENU BOARDS (prices only, ordering happens on jeetak)
     ===================================================================== */
  function renderMenu() {
    var boards = $('[data-boards]');
    var cats = $('[data-cats]');
    if (!boards || !cats) return;

    cats.innerHTML = MENU.map(function (cat) {
      return '<a class="cat" href="#cat-' + cat.id + '" data-cat-link="' + cat.id + '">' + esc(cat.name.replace(/^El King /, '')) + '</a>';
    }).join('');

    boards.innerHTML = MENU.map(function (cat) {
      var peek = cat.peek ? '<img class="board__peek" src="' + esc(cat.peek.src) + '" alt="" width="' + cat.peek.w + '" height="' + cat.peek.h + '" decoding="async">' : '';
      return '<article class="board' + (cat.peek ? ' board--peek' : '') + '" id="cat-' + cat.id + '" data-cat="' + cat.id + '" aria-labelledby="t-' + cat.id + '">' +
        peek +
        '<h3 class="board__title" id="t-' + cat.id + '">' + esc(cat.name) + '</h3>' +
        (cat.note ? '<p class="board__note">' + esc(cat.note) + '</p>' : '') +
        '<ul class="list">' + cat.items.map(renderItem).join('') + '</ul>' +
        '</article>';
    }).join('');

    // Masonry: drop each board into the shortest column, keeping menu order.
    var boardEls = $$('.board', boards);
    var cols = 0;
    function layout() {
      var w = boards.clientWidth;
      var n = w >= 1040 ? 3 : w >= 660 ? 2 : 1;
      if (n === cols) return;
      cols = n;
      boards.style.setProperty('--cols', n);
      var columns = [];
      boards.innerHTML = '';
      for (var i = 0; i < n; i++) {
        var c = document.createElement('div');
        c.className = 'boards__col';
        boards.appendChild(c);
        columns.push(c);
      }
      boardEls.forEach(function (b) {
        var target = columns.reduce(function (a, c) { return c.offsetHeight < a.offsetHeight ? c : a; });
        target.appendChild(b);
      });
    }
    layout();
    var rt;
    window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(layout, 120); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { cols = 0; layout(); });
  }

  function renderItem(it) {
    var names = '<div class="item__names"><span class="item__en">' + esc(it.en) +
      (it.star ? icon('i-crown', 'item__star') : '') + '</span>' +
      '<span class="item__ar" lang="ar" dir="rtl">' + esc(it.ar || '') + '</span></div>';
    var price;
    if (it.sizes) {
      price = '<div class="sizes">' + Object.keys(it.sizes).map(function (s) {
        var full = s === 'S' ? 'Small' : s === 'L' ? 'Large' : s;
        return '<span class="size"><abbr class="size__k" title="' + full + '">' + s + '</abbr>' + money(it.sizes[s]) + '</span>';
      }).join('') + '</div>';
    } else if (typeof it.price === 'number') {
      price = '<span class="price">' + money(it.price) + '</span>';
    } else {
      price = '<span class="price price--ask" title="Ask us, or check it on jeetak">ask</span>';
    }
    return '<li class="item">' + names + '<span class="item__dots" aria-hidden="true"></span>' + price + '</li>';
  }

  /* category chips follow the scroll */
  function initCatSpy() {
    var links = $$('[data-cat-link]');
    if (!links.length || !('IntersectionObserver' in window)) return;
    var current = null;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        var id = en.target.getAttribute('data-cat');
        if (id === current) return;
        current = id;
        links.forEach(function (l) {
          var on = l.getAttribute('data-cat-link') === id;
          l.classList.toggle('is-on', on);
          if (on) {
            l.setAttribute('aria-current', 'true');
            var bar = l.parentElement;
            bar.scrollTo({ left: l.offsetLeft - bar.clientWidth / 2 + l.clientWidth / 2, behavior: reduceMotion.matches ? 'auto' : 'smooth' });
          } else l.removeAttribute('aria-current');
        });
      });
    }, { rootMargin: '-35% 0px -60% 0px' });
    $$('.board').forEach(function (b) { io.observe(b); });
  }

  /* =====================================================================
     CRAVING CALLING — slide to answer, connects to jeetak
     ===================================================================== */
  function initCall() {
    var root = $('[data-call]');
    if (!root) return;
    var track = $('.call__track', root), knob = $('[data-call-knob]', root);
    var label = $('[data-call-label]', root), status = $('[data-call-status]', root);
    var x = 0, max = 0, startX = 0, dragging = false, moved = false, answered = false, resetT = null;

    function measure() { max = Math.max(0, track.clientWidth - knob.offsetWidth - 10); }
    function setX(v, animate) {
      x = Math.max(0, Math.min(max, v));
      knob.style.transition = animate ? 'transform .5s cubic-bezier(.34,1.56,.64,1)' : 'none';
      knob.style.transform = 'translateX(' + x + 'px)';
      root.style.setProperty('--p', max ? (x / max).toFixed(3) : 0);
    }
    knob.addEventListener('pointerdown', function (e) {
      if (answered) return;
      measure(); dragging = true; moved = false; startX = e.clientX - x;
      try { knob.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      root.classList.add('is-dragging');
    });
    knob.addEventListener('pointermove', function (e) {
      if (!dragging) return;
      var nx = e.clientX - startX;
      if (Math.abs(nx - x) > 2) moved = true;
      setX(nx, false);
    });
    function end() {
      if (!dragging) return;
      dragging = false;
      root.classList.remove('is-dragging');
      if (x >= max * 0.85) answer();
      else setX(0, true);
    }
    knob.addEventListener('pointerup', end);
    knob.addEventListener('pointercancel', end);
    knob.addEventListener('click', function (e) {
      if (answered) return;
      if (e.detail === 0) { measure(); answer(); return; } // keyboard
      if (!moved) {
        root.classList.remove('is-nudge'); void root.offsetWidth; root.classList.add('is-nudge');
        status.textContent = 'Slide the food to the pin to answer.';
      }
    });
    window.addEventListener('resize', function () { if (answered) { measure(); setX(max, false); } });

    function answer() {
      answered = true;
      setX(max, true);
      root.classList.add('is-answered');
      label.innerHTML = '<span>Connected to</span>' + JK_MARK;
      status.textContent = 'Opening El King on jeetak…';
      openJeetak();
      clearTimeout(resetT);
      resetT = setTimeout(reset, 10000);
    }
    function reset() {
      answered = false;
      root.classList.remove('is-answered');
      label.textContent = 'slide to answer';
      status.textContent = '';
      measure(); setX(0, true);
    }
  }

  /* =====================================================================
     WHICH ONE ARE YOU? gauge
     ===================================================================== */
  function initGauge() {
    var g = $('[data-gauge]');
    if (!g || !MOODS.length) return;
    var segs = $$('.gauge__seg', g), needle = $('.gauge__needle', g);
    var quote = $('[data-gauge-quote]', g), combo = $('[data-gauge-combo]', g), total = $('[data-gauge-total]', g);
    function select(i) {
      var m = MOODS[i];
      segs.forEach(function (s, j) { s.classList.toggle('is-on', j === i); s.setAttribute('aria-pressed', j === i ? 'true' : 'false'); });
      needle.style.transform = 'rotate(' + (-67.5 + i * 45) + 'deg)';
      quote.textContent = '“' + m.line + '”';
      var sum = 0, ask = 0;
      combo.innerHTML = m.combo.map(function (c) {
        var u = unitPrice(c[0], c[1]);
        if (u == null) ask++; else sum += u;
        return '<li>' + esc(itemLabel(c[0], c[1])) + '</li>';
      }).join('');
      total.textContent = money(sum) + (ask ? ' +' : '');
    }
    segs.forEach(function (s, i) {
      s.addEventListener('click', function () { select(i); });
      s.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(i); }
        if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
          e.preventDefault();
          var n = (i + (e.key === 'ArrowRight' ? 1 : -1) + segs.length) % segs.length;
          segs[n].focus(); select(n);
        }
      });
    });
    select(1);
  }

  /* =====================================================================
     EL KING IS ON JEETAK — route, pin drop, reveal
     ===================================================================== */
  function initJeetak() {
    var band = $('[data-jkband]');
    if (!band) return;
    var scene = $('[data-jkscene]', band);
    var motion = scene && scene.querySelector('animateMotion');
    if (reduceMotion.matches || !('IntersectionObserver' in window)) { band.classList.add('is-in'); return; }
    band.classList.add('is-armed');
    var io = new IntersectionObserver(function (entries) {
      if (!entries[0].isIntersecting) return;
      io.disconnect();
      band.classList.add('is-in');
      if (motion && motion.beginElementAt) { try { motion.beginElementAt(0.6); } catch (e) { /* SMIL unsupported */ } }
    }, { threshold: 0.3 });
    io.observe(scene || band);
  }

  /* =====================================================================
     MOBILE NAV
     ===================================================================== */
  function initMobileNav() {
    var btn = $('[data-burger]'), panel = $('[data-mnav]');
    if (!btn || !panel) return;
    btn.addEventListener('click', function () {
      var open = btn.getAttribute('aria-expanded') !== 'true';
      btn.setAttribute('aria-expanded', open);
      panel.classList.toggle('is-open', open);
      document.documentElement.style.overflow = open ? 'hidden' : '';
    });
    panel.addEventListener('click', function (e) { if (e.target.closest('a')) closeMobileNav(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMobileNav(); });
  }
  function closeMobileNav() {
    var btn = $('[data-burger]'), panel = $('[data-mnav]');
    if (!btn || btn.getAttribute('aria-expanded') !== 'true') return;
    btn.setAttribute('aria-expanded', 'false');
    panel.classList.remove('is-open');
    document.documentElement.style.overflow = '';
  }

  /* =====================================================================
     VIDEOS — play when on screen, tap for sound
     ===================================================================== */
  function initWall() {
    var wall = $('.wall');
    if (!wall) return;
    var imgs = $$('img', wall);
    function loadAll() { imgs.forEach(function (i) { i.loading = 'eager'; }); }
    if (!('IntersectionObserver' in window)) { loadAll(); return; }
    var io = new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting) { loadAll(); io.disconnect(); }
    }, { rootMargin: '1200px 0px' });
    io.observe(wall);
  }

  function initReels() {
    var vids = $$('.reel video');
    if (!vids.length) return;
    var auto = !reduceMotion.matches;
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          var v = en.target;
          if (en.isIntersecting) {
            if (v.preload === 'none') v.preload = 'auto';
            if (auto) { var p = v.play(); if (p && p.catch) p.catch(function () {}); }
          } else v.pause();
        });
      }, { threshold: 0.4 });
      vids.forEach(function (v) { io.observe(v); });
    }
    $$('.reel__sound').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var v = btn.parentElement.querySelector('video');
        var turnOn = v.muted;
        vids.forEach(function (o) {
          o.muted = true;
          var b = o.parentElement.querySelector('.reel__sound');
          b.setAttribute('aria-pressed', 'false'); b.setAttribute('aria-label', 'Turn sound on');
        });
        v.muted = !turnOn;
        btn.setAttribute('aria-pressed', turnOn ? 'true' : 'false');
        btn.setAttribute('aria-label', turnOn ? 'Turn sound off' : 'Turn sound on');
        if (v.paused) { var p = v.play(); if (p && p.catch) p.catch(function () {}); }
      });
    });
    vids.forEach(function (v) {
      v.addEventListener('click', function () {
        if (v.paused) { var p = v.play(); if (p && p.catch) p.catch(function () {}); } else v.pause();
      });
    });
  }

  /* =====================================================================
     THE CREATION OF APPETITE — hands meet as you scroll
     ===================================================================== */
  function initCreation() {
    var art = $('[data-creation]');
    if (!art) return;
    if (reduceMotion.matches) { art.style.setProperty('--gap', '0%'); art.style.setProperty('--spark', 1); return; }
    var ticking = false, active = false;
    function update() {
      ticking = false;
      var r = art.getBoundingClientRect(), vh = window.innerHeight;
      var p = (vh - r.top) / (vh * 0.75 + r.height * 0.25);
      var q = Math.max(0, Math.min(1, p / 0.88));
      var eased = 1 - Math.pow(1 - q, 2);
      art.style.setProperty('--gap', ((1 - eased) * 16).toFixed(2) + '%');
      art.style.setProperty('--spark', q >= 1 ? 1 : 0);
    }
    function onScroll() { if (active && !ticking) { ticking = true; requestAnimationFrame(update); } }
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) { active = en[0].isIntersecting; if (active) update(); }, { rootMargin: '20% 0px' }).observe(art);
    } else active = true;
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    update();
  }

  /* ---------- go: each part runs on its own, so one failure can't stop the rest ---------- */
  [applyLinks, renderMenu, initCatSpy, initCall, initGauge, initJeetak, initMobileNav, initWall, initReels, initCreation]
    .forEach(function (fn) {
      try { fn(); } catch (err) { if (window.console) console.error('[El King] ' + (fn.name || 'init') + ' failed:', err); }
    });
})();
